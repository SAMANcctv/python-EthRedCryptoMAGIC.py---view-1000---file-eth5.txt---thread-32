# RED Crypto MAGIC

![Red Crypto Magic Crack And Hack Private Key Wallet From Mnemonic](https://raw.githubusercontent.com/Pymmdrza/REDCryptoMAGIC/mainx/RedCryptoMagicPNG.png)

## RED CRYPTO MAGIC ~ Hunt and Crack Private Key (Bytes & Hex) With Mnemonic

For Running This Script First Install Package's (Windows):
```
pip install bip_utils
pip install rich
pip install optparse
```

On Linux : `pip3 install rich bip_utils optparse`


### Ethereum Hunting and Crack Private Key From Mnemonic:
```
  -h OR --help          show this help message and exit
  -f OR --file          Ethereum Rich Address File With Type Format .TXT [Example: -f eth5.txt or --file eth5.txt]
  -v OR --view          Print After Generated This Number Print And Report
  -n OR --thread        Total Thread Number (Total Core CPU)
```

![Ethereum RED Crypto Magic ](https://raw.githubusercontent.com/Pymmdrza/REDCryptoMAGIC/mainx/EthRedCrypto.png)

Example for running `EthRedCryptoMAGIC.py` After 1000 Key Generated and LOADED Address From File `eth5.txt` with 32 Thread/Core :

`python EthRedCryptoMAGIC.py -v 1000 -f eth5.txt -n 32`

or

`python EthRedCryptoMAGIC.py --view 1000 --file eth5.txt --thread 32`

---
### Polkadot Hunting And Crack Private Key From Mnemonic:
```
python DotRedCryptoMAGIC.py -f dot1000.txt -v 1000 -n 32
```

![](https://raw.githubusercontent.com/Pymmdrza/REDCryptoMAGIC/mainx/DotRedCrypto.png)

For Running DotCryptoMAGIC.py Needed Rich Address Wallet On Text File . Can [Download Here](https://github.com/Pymmdrza/Rich-Address-Wallet/tree/main/DOT 'Rich Address Wallet List Polkadot DOT')



✨ Donate Programmer BTC ADDRESS : `15hHp8orzFTwQVc8S8xSFkwnamfJ5ZzZ8R`
```
Programmer Mmdrza.Com
Telegram ID ~ @MrPyMmdrza
Telegram Channel ~ @Cryptoixer
Github @Pymmdrza
```
